# Azure DevOps Multi-Cloud Terraform Pipelines

## Service connections used

| Cloud | Service connection | Expected Azure DevOps endpoint type | Pipeline task usage |
|---|---|---|---|
| Azure | `sc-azure-terraform-wif` | `azurerm` / Azure Resource Manager | `TerraformTaskV4@4` AzureRM inputs |
| AWS | `sc-aws-terraform-wif` | `AWS` | `AWSShellScript@1` `awsCredentials` input |
| GCP | `sc-gcp-wif-token` | `azurerm` / Azure Resource Manager | `AzureCLI@2` obtains Azure DevOps ID token for Google Workload Identity Federation |

The GCP service connection is intentionally an Azure Resource Manager endpoint. It is not passed to TerraformTaskV4 GCP inputs. The pipeline obtains the Azure DevOps ID token through `AzureCLI@2` and creates a Google external-account credential configuration for Terraform ADC.

## Required Azure DevOps pipeline variables for GCP

Create these non-secret pipeline variables (or add them to a variable group linked to this pipeline):

- `GCP_WIF_PROJECT_NUMBER`: numeric project number of the Google Cloud project that owns the Workload Identity Pool.
- `GCP_WIF_POOL_ID`: Workload Identity Pool ID.
- `GCP_WIF_PROVIDER_ID`: OIDC provider ID in that pool.
- `GCP_TERRAFORM_SERVICE_ACCOUNT`: service account email that the federated identity is allowed to impersonate.

The pipeline creates a short-lived credential file at runtime; do not store an ID token or service-account key in pipeline variables.

## Files

- `multi-cloud-deployment.yml`: orchestrator with cloud selection (`all`, `azure`, `aws`, `gcp`) and operation selection (`plan`, `apply`, `destroy`).
- `templates/azure-deployment.yml`: Azure Terraform stages.
- `templates/aws-deployment.yml`: AWS Terraform stages using the AWS Toolkit shell task.
- `templates/gcp-deployment.yml`: GCP Terraform stages using Azure DevOps-to-Google Workload Identity Federation.
- `self-hosted-test.yml`: local RHEL agent verification pipeline.

All deployment jobs use the `Local-Linux-Agents` pool.
